export class Task {
    taskName = '';
    status = '';
    constructor() {
        
    }
}